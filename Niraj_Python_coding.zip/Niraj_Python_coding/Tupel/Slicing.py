# Slicing of a Tuple 

# Slicing of a Tuple 
# with Numbers 
Tuple1 = tuple('PYTHONFORGAMES') 

# Removing First element 
print("Removal of First Element: ") 
print(Tuple1[1:]) 

# Reversing the Tuple 
print("\nTuple after sequence of Element is reversed: ") 
print(Tuple1[::-1]) 

# Printing elements of a Range 
print("\nPrinting elements between Range 4-9: ") 
print(Tuple1[4:9]) 

# Deleting a Tuple 

Tuple1 = (0, 1, 2, 3, 4) 
del Tuple1 

print(Tuple1) 

