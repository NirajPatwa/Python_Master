x = 5
y = 10
x, y = y, x 
print ("After Swapping values of x and y are", x, y) 
