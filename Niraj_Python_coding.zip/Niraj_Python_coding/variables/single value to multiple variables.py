x=y=z=50  
print (x);
print (y); 
print (z);
