# Python program to demonstrate 
# accessing of element from list 

# Creating a List with 
# the use of multiple values 
List = ["Pyhon", "For", "Game"] 

# accessing a element from the 
# list using index number 
print("Accessing a element from the list") 
print(List[0]) 
print(List[2]) 

# Creating a Multi-Dimensional List 
# (By Nesting a list inside a List) 
List = [['Python', 'For'] , ['AI']] 

# accessing a element from the 
# Multi-Dimensional List using 
# index number 
print("Acessing a element from a Multi-Dimensional list") 
print(List[0][1]) 
print(List[1][0]) 


List = [1, 2, 'Python', 4, 'For', 6, 'ML'] 

# accessing a element using 
# negative indexing 
print("Acessing element using negative indexing") 

# print the last element of list 
print(List[-1]) 

# print the third last element of list 
print(List[-3]) 
