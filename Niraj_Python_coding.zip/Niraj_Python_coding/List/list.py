##a  = [1, "hi", "python", 2]  
##print (a[3:]);  
##print (a[0:2]);  
##print (a);  
##print (a + a);  
##print (a * 3); 
##
##
fruits = ["apple", "banana", "cherry","apple", "banana", "cherry"]
##print(fruits)
##
##
##print(fruits[1])##Access Items
##
##
##fruits[1] = "blackcurrant"##Change Item Value
##print(fruits)
##
##
##for x in fruits: ##Loop
##  print(x)
##
##
##if "apple" in fruits:    ##Check if Item Exists
##  print("Yes, 'apple' is in the fruits list")
##
##
## print(len(fruits))##List Length
##
##fruits.append("orange")  ##Add Items
##print(fruits)
##
##
##fruits.insert(1, "orange")####Add Items
##print(fruits)
##
##fruits = ["apple", "banana", "cherry"]
##fruits.remove("banana")##Remove
##print(fruits)
##
##
##fruits.pop()##The pop() method removes the specified index, (or the last item if index is not specified)
##print(fruits)
####
##del fruits[0]##The del keyword removes the specified index:
##print(fruits)
##
##fruits = ["apple", "banana", "cherry"]
##del fruits##The del keyword can also delete the list completely:
##
##fruits = ["apple", "banana", "cherry"]
##fruits.clear()##The clear() method empties the list:
##print(fruits)
##
##fruits = list(("apple", "banana", "cherry")) # Using the list() constructor to make a List.note the double round-brackets
##print(fruits)
##x=10,fruits.copy()
######x = fruits.copy()
##print(x)
##print(type(x))
##
##x = fruits.count("cherry")
##
##print(x)
##
##points = [1, 4, 2, 9, 7, 8, 9, 3, 1]
##
##x = points.count(9)
##print(x)
##
##
##fruits = ['apple', 'banana', 'cherry']
##
##cars = ['Ford', 'BMW', 'Volvo']
##cars1 = ['Ford1', 'BMW1', 'Volvo1']
##cars2 = ['Ford2', 'BMW2', 'Volvo2']
##cars3 = ['Ford3', 'BMW3', 'Volvo3']
##
##fruits.extend(cars)
##fruits.extend(cars1)
##fruits.extend(cars2)
##fruits.extend(cars3)
##
##print(fruits)
##
cars = ['Ford', 'BMW', 'Volvo']

cars.sort()
print (cars)
##
##
##
##
##
##
##
##
##
##  
