def getITNames():  
    List = ["John", "David", "Nick",    "Martin"]  
    return List; 
