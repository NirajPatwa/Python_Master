#Accessing Values in Strings
var1 = "SIT.CS!"
var2 = "Software Testing"
##print ("var1[0]:",var1[0])
##print ("var2[1:5]:",var2[1:5])
###Some more examples
##x = "Hello World!"
##print (x[:6]) 
##print x[0:6] + "SIT.CS"
###Python String replace() Method
##oldstring = 'I like Python' 
##newstring = oldstring.replace('like', 'love')
##print newstring
###Changing upper and lower case strings
##string="python at SIT.CS"
##print string.upper()
##string="python at SIT.CS"		
##print string.capitalize()
##string="PYTHON AT SIT.CS"
##print string.lower()
###Using "join" function for the string
print str1.join("Python")		
###Reversing String
##string="12345"		
##print''.join(reversed(string))
###Split Strings
##word="SIT.CS career Python"		
##print word.split(' ')
##word="SIT.CS career Python"		
##print word.split('r')
##x = "SIT.CS"
##x.replace("SIT.CS","Python")
##print x
##x = "SIT.CS"
##x = x.replace("SIT.CS","Python")
##print x
