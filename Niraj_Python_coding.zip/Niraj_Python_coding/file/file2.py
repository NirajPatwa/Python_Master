import os;  
  
#rename file2.txt to file3.txt  
os.rename("test.txt","TEST.txt")

##if os.rename:
##    print("ok")
##else:
##    print("not ok")



os.remove("TEST.txt")  
    
