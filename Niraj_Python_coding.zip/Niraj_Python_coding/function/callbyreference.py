 
def change_list(list11):  
    list10.append(20);  
    list10.append(30);  
    print("list inside function = ",list11)  

#defining the list  
list10 = [10,30,40,50]
list11 = [11,31,41,51]
  
#calling the function   
change_list(list11);  
print("list outside function = ",list10);






