##i=1;  
##while i<=10:  
##    print(i);  
##    i=i+1;



##i=1  
##number=0  
##b=9  
##number = int(input("Enter the number?"))  
##while i<=10:  
##    print("%d X %d = %d \n"%(number,i,number*i));  
##    i = i+1;  


while (1):  
    print("i"); 



##var = 1  
##while var != 2:  
##    i = int(input("Enter the number?"))  
##    print ("Entered value is %d"%(i))  

##
##i=1;  
##while i<=5:  
##    print(i)  
##    i=i+1;  
##else:print("The while loop exhausted");




i=1;  
while i<=5:  
    print(i)  
    i=i+1;  
    if(i==3):  
        break;  
else:print("The while loop exhausted");  
