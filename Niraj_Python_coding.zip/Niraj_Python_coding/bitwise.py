if a = 7;  
   b = 6;   
then, binary (a) = 0111  
    binary (b) = 0011  
  
hence, a & b = 0011  
      a | b = 0111  
             a ^ b = 0100  
       ~ a = 1000   
